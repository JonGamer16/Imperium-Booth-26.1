advancement revoke @s only imperium:consume_knife

# 1. Spawn a snowball to natively acquire the player's directional vector
execute \
    at @s \
    anchored eyes \
    run summon snowball ^ ^ ^ {Tags:["aim_assist"]}

# 2. Spawn the Arrow projectile
# damage: Set to 5.0d (Arrows multiply this base damage by their speed).
# pickup: 1b allows the arrow to be recovered.
# item: Defines exactly what item goes into the inventory when picked up.
execute \
    at @s \
    anchored eyes \
    run summon arrow ^ ^ ^ \
        {\
            Tags:["knife_proj"],\
            pickup:1b,\
            damage:5.0d,\
            item:{\
                id:"minecraft:iron_sword",\
                count:1,\
                components:{\
                    "minecraft:custom_data":"{knife:1b}",\
                    "minecraft:consumable":{\
                        consume_seconds:0.5f,\
                        animation:"bow"},\
                    "minecraft:item_name":\
                        '{"text":"Throwing Knife"}'\
        }}}

# 3. Copy the motion vector from the Snowball to the Arrow
data modify entity @n[type=arrow,tag=knife_proj] Motion set from entity @n[type=snowball,tag=aim_assist] Motion

# 4. Set Speed Multiplier (e.g., 2) and execute scaling math
scoreboard players set #SPEED im_temp 2
execute as @n[type=arrow,tag=knife_proj] run function imperium:items/throwing_knife/speed

# 5. Cleanup
kill @e[type=snowball,tag=aim_assist]
tag @e[type=arrow,tag=knife_proj] remove knife_proj