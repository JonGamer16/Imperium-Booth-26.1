give @s iron_sword[custom_data={knife:1b},consumable={consume_seconds:0.5,animation:"bow"},item_name='{"text":"Throwing Knife"}'] 1
